CREATE VIEW V_$SGA_DYNAMIC_FREE_MEMORY AS select "CURRENT_SIZE" from v$sga_dynamic_free_memory
/
