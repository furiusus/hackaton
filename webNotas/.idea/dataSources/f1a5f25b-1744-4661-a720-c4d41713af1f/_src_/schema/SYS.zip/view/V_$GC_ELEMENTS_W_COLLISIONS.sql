CREATE VIEW V_$GC_ELEMENTS_W_COLLISIONS AS select "GC_ELEMENT_ADDR" from v$gc_elements_with_collisions
/
