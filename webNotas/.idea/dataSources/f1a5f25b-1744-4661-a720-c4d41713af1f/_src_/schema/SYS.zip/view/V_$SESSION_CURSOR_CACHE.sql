CREATE VIEW V_$SESSION_CURSOR_CACHE AS select "MAXIMUM","COUNT","OPENS","HITS","HIT_RATIO" from v$session_cursor_cache
/
