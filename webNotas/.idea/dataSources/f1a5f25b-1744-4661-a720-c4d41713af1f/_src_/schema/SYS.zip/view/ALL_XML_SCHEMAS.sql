CREATE VIEW ALL_XML_SCHEMAS AS select u.name, s.xmldata.schema_url,
          case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 16) = 16
               then 'NO' else 'YES' end,
	  case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 16384) = 16384
               then xdb.dbms_csx_int.GetCSXSchema(xmltype(value(s).getclobval())) else value(s) end,
          xdb.dbms_xmlschema_int.xdb$Oid2IntName(s.object_id),
          case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 16) = 16
               then s.xmldata.schema_url
               else 'http://xmlns.oracle.com/xdb/schemas/' ||
                    s.xmldata.schema_owner || '/' ||
                    case when substr(s.xmldata.schema_url, 1, 7) = 'http://'
                         then substr(s.xmldata.schema_url, 8)
                         else s.xmldata.schema_url
                    end
          end,
          case when bitand(to_number(s.xmldata.flags, 'xxxxxxxx'), 128) = 128
               then 'NONE'
               else case when
                    bitand(to_number(s.xmldata.flags, 'xxxxxxxx'), 64) = 64
                    then  'RESMETADATA'
                    else  'CONTENTS'
                    end
          end,
          case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 16384) = 16384
              then 'YES' else 'NO' end,
          s.sys_nc_oid$,
          case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 32768) = 32768
              then 'YES' else 'NO' end
    from user$ u, xdb.xdb$schema s
    where u.user# = userenv('SCHEMAID')
    and   u.name  = s.xmldata.schema_owner
    union all
    select s.xmldata.schema_owner, s.xmldata.schema_url, 'NO', value(s),
          xdb.dbms_xmlschema_int.xdb$Oid2IntName(s.object_id),
          s.xmldata.schema_url,
          case when bitand(to_number(s.xmldata.flags, 'xxxxxxxx'), 128) = 128
               then 'NONE'
               else case when
                    bitand(to_number(s.xmldata.flags, 'xxxxxxxx'), 64) = 64
                    then  'RESMETADATA'
                    else  'CONTENTS'
                    end
          end,
          case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 16384) = 16384
              then 'YES' else 'NO' end,
          s.sys_nc_oid$,
          case when bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 32768) = 32768
              then 'YES' else 'NO' end
    from xdb.xdb$schema s
    where bitand(to_number(s.xmldata.flags,'xxxxxxxx'), 16) = 16
    and s.xmldata.schema_url
       not in (select s2.xmldata.schema_url
               from xdb.xdb$schema s2, user$ u2
               where u2.user# = userenv('SCHEMAID')
               and   u2.name  = s.xmldata.schema_owner)
/
COMMENT ON VIEW ALL_XML_SCHEMAS IS 'Description of all XML Schemas that user has privilege to reference'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.OWNER IS 'Owner of the XML Schema'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.SCHEMA_URL IS 'Schema URL of the XML Schema'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.LOCAL IS 'Is this XML Schema local or global'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.SCHEMA IS 'The XML Schema document'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.INT_OBJNAME IS 'The internal database object name for the schema'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.QUAL_SCHEMA_URL IS 'The fully qualified schema URL'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.HIER_TYPE IS 'The type of hierarchy for which the schema is enabled'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.BINARY IS 'Is this XML Schema registered for binary encoding usage?'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.SCHEMA_ID IS '16 byte opaque schema identifier'
/
COMMENT ON COLUMN ALL_XML_SCHEMAS.HIDDEN IS 'Has this XML Schema been deleted in hidden mode?'
/
