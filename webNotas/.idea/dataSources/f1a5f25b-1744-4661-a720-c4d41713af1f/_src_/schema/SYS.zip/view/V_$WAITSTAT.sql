CREATE VIEW V_$WAITSTAT AS select "CLASS","COUNT","TIME" from v$waitstat
/
