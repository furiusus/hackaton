CREATE VIEW V_$PQ_SYSSTAT AS select "STATISTIC","VALUE" from v$pq_sysstat
/
