CREATE VIEW GV_$DBFILE AS select "INST_ID","FILE#","NAME" from gv$dbfile
/
